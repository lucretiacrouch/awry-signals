#import time
import datetime
import random

#list of astroseismology values, faster than reading in txt file
data = [0.001, 0.0015, 0.002, 0.003, 0.005, 0.002, 0.0015, 0.0025, 0.003, 0.0048, 0.0025, 0.0012, 0.001, 0.001, 0.0018, 0.002, 0.001, 0.0015, 0.0025, 0.0012, 0.0008, 0.001, 0.0012, 0.001, 0.001, 0.0012, 0.002, 0.00375, 0.007, 0.0055, 0.016, 0.0075, 0.005, 0.0025, 0.004, 0.003, 0.0032, 0.0035, 0.001, 0.00175, 0.0025, 0.002, 0.0021, 0.0024, 0.001, 0.001, 0.0022, 0.002, 0.0018, 0.001, 0.0012, 0.001, 0.0013, 0.001, 0.0006, 0.002, 0.001, 0.0008, 0.0012, 0.0015]
print('Alpha Centauri starlight wifi within range at ', data[0], 'mHz')
#variables
data_length = len(data)
#index positions of data are 0 to data_length - 1

####################
#load in text files of answers from dead stars
#Chrissy Amphlett
chrissy01 = ['Chrissy says:']
chrissy02 = ['Chrissy says:']
#Poly Styrene
poly01 = ['Poly says:']
poly02 = ['Poly says:']
#Ari Up
ari01 = ['Ari says:']
ari02 = ['Ari says:']

def load_answers(which_array, which_file):
    # Open the input text file for reading
    # text files need at least 20 lines as max value 17 plus 2
    dataFile = open(which_file, 'r', encoding='utf-8')
    for line in dataFile:
        #strip off line returns
        line = line.rstrip()
        #add line to array
        which_array.append(line)
    #test
    #print(which_array)
    #close file
    dataFile.close()
#end load_answers function  

load_answers(chrissy01, 'chrissy01.txt')
load_answers(poly01, 'poly01.txt')
load_answers(ari01, 'ari01.txt')
load_answers(chrissy02, 'chrissy02.txt')
load_answers(poly02, 'poly02.txt')
load_answers(ari02, 'ari02.txt')

#end loading in text files of answers from dead stars
####################


# function to insert pauses
def pause(howlong):
    #find current time's number of seconds
    start_time = int(datetime.datetime.now().strftime("%S"))
    counter = start_time    
    duration = howlong
    end_time = start_time + duration
    #check if duration would go over into next minute
    if end_time > 59:
        end_time = end_time - 59
    #wait until duration is up
    while counter <= end_time:
        counter = int(datetime.datetime.now().strftime("%S"))
#end pause function

        
####################
#infinite repeat loop

##nancy types a question
## show connecting....
## retrieve time current seconds
## use time to retrieve corrresponding data index 0 to 59
## use data to retrieve number of answers from each of the 3

while 1:
    #variables
    #initial dfault value for signal strength
    signal_strength = 0.01
    print(' ')
    print('  >>> Searching for signal')
    print('  ~~~   ~~~   ~~~   ~~~>>>')
    print('  >>> Initialising connection')
    print(' ')
    #user input kicks off program
    question = input('Ask your question of the ascending dead, warriors who disapear over this horizon and reform as clusters of stars: ')
    question_lower = question.lower()
    #find time's number of seconds now
    start_time = int(datetime.datetime.now().strftime("%S"))
    #retrieve data value at that index position
    signal_strength = data[start_time] 
    
    #calculate signal strength - drop out, weak, strong etc & number of lines to grab
    #user feedback to show connecting
    print('  >>> Question :: ', question, ' :: undergoing compression.')
    
    #check for very low strength signal
    if signal_strength < 0.001:
        print(' ')
        print(' ||| ø  SIGNAL DROP OUT  ø |||')
        #find time's number of seconds now
        start_time = int(datetime.datetime.now().strftime("%S"))
        #retrieve data value at that index position
        signal_strength = data[start_time]
        print(' >>> Attempting re-connection')
        print(' ')
        print('  >>> Searching for signal')
        print('  ~~~   ~~~   ~~~   ~~~>>>')
        #end if
    #if signal is useable strength, find responses
    num_lines = int(signal_strength * 1000) + 2
    print(' ')
    print('  >>> Starlight wifi signal strength: ', signal_strength)
    print('  >>> In communication')
    print('  >>> Question sent')
    print(' ')
    #check question
    if 'like' in question_lower:
        print('  Response detected  <<<')
        print('                     <<< ')
        #find point in responses where there are enough lines           
        c_max_index = (len(chrissy01) -1) - num_lines
        p_max_index = (len(poly01) - 1) - num_lines
        a_max_index = (len(ari01) - 1) - num_lines
        #find random start point in lines
        c_index = random.randrange(1, c_max_index)
        p_index = random.randrange(1, p_max_index)
        a_index = random.randrange(1, a_max_index)
        for i in range(0, num_lines):
            #pause(1)
            print('   ', chrissy01[0], chrissy01[c_index])
            c_index += 1
            #print('c_index', c_index)
            pause(1)
            print('   ', poly01[0], poly01[p_index])
            p_index += 1
            #print('p_index', p_index)
            pause(1)
            print('   ', ari01[0], ari01[a_index])
            a_index += 1
            pause(1)
            #print('a_index', a_index)           
        print(' ')
        print('------------------------------')
        print('  >>> Response complete')
        print(' ')
    else:
        print('||| X Cannnot parse the question  X |||' )
#end infinite loop   
#####################
